package com.syc.perms.mapper;

import com.syc.perms.pojo.TbUsers;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 *
 */
public interface MainMapper {

    @Select("SELECT * FROM tb_users WHERE TO_DAYS(NOW()) = TO_DAYS(create_time); ")
    List<TbUsers> getTodayUsers();

    @Select("SELECT * FROM tb_users WHERE TO_DAYS(NOW()) - TO_DAYS(create_time) = 1 ;")
    List<TbUsers> getUsersYesterday();

    @Select("SELECT * FROM tb_users WHERE YEARWEEK(DATE_FORMAT(create_time,'%Y-%m-%d')) = YEARWEEK(NOW());")
    List<TbUsers> getUsersYearWeek();

    @Select("SELECT * FROM tb_users WHERE DATE_FORMAT(create_time,'%Y%m') = DATE_FORMAT(CURDATE(),'%Y%m');")
    List<TbUsers> getUsersMonth();

}
