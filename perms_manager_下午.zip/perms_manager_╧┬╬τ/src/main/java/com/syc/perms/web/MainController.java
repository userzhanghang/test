package com.syc.perms.web;

import com.syc.perms.pojo.TbUsers;
import com.syc.perms.service.MainService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 */
@Controller
@RequestMapping("/main")
public class MainController {

    @Autowired
    private MainService mainService;

    /**
     * 鏌ヨ鎬荤殑鐢ㄦ埛
     */
    @ResponseBody
    @RequestMapping(value = "/getUserTotal", method = RequestMethod.GET)
    public List<TbUsers> getTotalUser() {

        return mainService.getUsers();
    }

    /**
     * 鏌ヨ浠婂ぉ鍒涘缓鐨勭敤鎴�
     */
    @ResponseBody
    @RequestMapping(value = "/getUsersToday", method = RequestMethod.GET)
    public List<TbUsers> getUsersToday() {

        return mainService.getTodayUsers();
    }

    @ResponseBody
    @RequestMapping(value = "/getUsersYesterday", method = RequestMethod.GET)
    public List<TbUsers> getUsersYesterday() {
        return mainService.getUsersYesterday();
    }

    @ResponseBody
    @RequestMapping(value = "/getUsersYearWeek", method = RequestMethod.GET)
    public List<TbUsers> getUsersYearWeek() {

        return mainService.getUsersYearWeek();
    }

    @ResponseBody
    @RequestMapping(value = "/getUsersMonth", method = RequestMethod.GET)
    public List<TbUsers> getUsersMonth() {

        return mainService.getUsersMonth();
    }

    /**
     * 缁熻姣忎釜鎬у埆鐨勪汉鏁�
     * {'categories':,'values':'xxx'}
     */
    @ResponseBody
    @RequestMapping(value = "/dataAccessGender", method = RequestMethod.GET)
    public Map<String, Object> dataAccessGender() {
        Map<String, Object> map = new HashMap<>();
        String[] categories = {"鐢�", "濂�", "淇濆瘑"};
        //
        map.put("categories", categories);

        List<Map<String, Object>> values = new ArrayList<>();
        for (int sex = 0; sex < categories.length; sex++) {
            //鏌ヨ鍑轰笉鍚屾�у埆鐨勬暟閲�
            long sexCount = mainService.countByGender(sex);

            //涓�涓猰ap鏄竴涓�у埆
            Map<String, Object> json = new HashMap<>();
            json.put("value", sexCount);
            json.put("name", categories[sex]);
            values.add(json);
        }

        //涓嶅悓鎬у埆鐨勬暟閲�
        map.put("values", values);

        return map;
    }

}
