package com.syc.perms.service;

import com.syc.perms.pojo.*;

import java.util.List;

/**
 *
 */
public interface AdminService {

    TbAdmin findAdminByName(String username);

    List<Menu> getMenus(TbAdmin admin);

    TbAdmin findAdminByNameAndPwd(String username, String oldPwd);

    void updatePwd(TbAdmin admin);

    R getRoleList(Integer page, Integer limit);

    void addRole(TbRoles role, String menuId);

    List<TbMenus> getRolePermissionTree(TbAdmin admin);

    TbRoles getRoleByName(String roleName);

    TbRoles getRoleById(Long roleId);

    void updateRole(TbRoles role, String menuIds);

    void deleteOne(Long roleId);

    void deleteMore(String roleIds);

}
