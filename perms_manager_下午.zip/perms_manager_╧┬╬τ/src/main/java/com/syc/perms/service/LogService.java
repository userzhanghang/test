package com.syc.perms.service;

import com.syc.perms.pojo.R;
import com.syc.perms.pojo.TbLog;
import com.syc.perms.pojo.UserSearch;

/**
 *
 */
public interface LogService {

    void saveLog(TbLog log);

    R getLogList(Integer page, Integer limit, UserSearch search);
}
