package com.syc.perms.service.impl;

import com.syc.perms.mapper.MainMapper;
import com.syc.perms.mapper.TbUsersMapper;
import com.syc.perms.pojo.TbUsers;
import com.syc.perms.pojo.TbUsersExample;
import com.syc.perms.service.MainService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 *
 */
@Service
public class MainServiceImpl implements MainService {

    @Autowired
    private TbUsersMapper usersMapper;

    @Autowired
    private MainMapper mainMapper;

    @Override
    public List<TbUsers> getUsers() {
        //select * from tb_users;
        return usersMapper.selectByExample(new TbUsersExample());
    }

    @Override
    public List<TbUsers> getTodayUsers() {

        return mainMapper.getTodayUsers();
    }

    @Override
    public List<TbUsers> getUsersYesterday() {

        return mainMapper.getUsersYesterday();
    }


    @Override
    public List<TbUsers> getUsersYearWeek() {
        return mainMapper.getUsersYearWeek();
    }

    @Override
    public List<TbUsers> getUsersMonth() {

        return mainMapper.getUsersMonth();
    }

    @Override
    public long countByGender(int sex) {
        TbUsersExample example = new TbUsersExample();
        example.createCriteria().andSexEqualTo(String.valueOf(sex));
        return usersMapper.countByExample(example);
    }

}
