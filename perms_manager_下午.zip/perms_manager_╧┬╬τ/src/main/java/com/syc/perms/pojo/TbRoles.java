package com.syc.perms.pojo;

import lombok.Data;

@Data
public class TbRoles {

    private Long roleId;

    private String roleName;

    private String roleRemark;

}