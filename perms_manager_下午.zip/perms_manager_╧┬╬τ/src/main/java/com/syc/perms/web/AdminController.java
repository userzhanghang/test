package com.syc.perms.web;

import com.syc.perms.annotation.SysLog;
import com.syc.perms.pojo.R;
import com.syc.perms.pojo.TbAdmin;
import com.syc.perms.pojo.TbMenus;
import com.syc.perms.pojo.TbRoles;
import com.syc.perms.service.AdminService;
import com.syc.perms.util.JsonUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 *
 */
@Controller
@RequestMapping("/sys")
public class AdminController {

    @Autowired
    private AdminService adminService;

    @RequestMapping(value = "/roleList", method = RequestMethod.GET)
    @RequiresPermissions({"sys:role:list"})
    public String showRoleList() {
        return "page/admin/roleList";
    }

    //RequiresPermissions:访问该接口需要具有如下权限
    @ResponseBody
    @RequestMapping(value = "/getRoleList", method = RequestMethod.GET)
    @RequiresPermissions({"sys:role:list"})
    public R getRoleList(Integer page, Integer limit) {
        //page:当前页码;limit:每页多少条
        return adminService.getRoleList(page, limit);
    }

    @RequestMapping(value = "/addRole", method = RequestMethod.GET)
    public String showAddRole() {
        return "page/admin/addRole";
    }

    @ResponseBody
    @RequestMapping(value = "/addRole", method = RequestMethod.POST)
    public R addRole(TbRoles role, @RequestParam("m") String menuId) {

        TbRoles tbRoles = adminService.getRoleByName(role.getRoleName());
        if (tbRoles != null) {
            return new R(500, "角色已存在");
        }

        adminService.addRole(role, menuId);

        return R.ok();
    }

    @ResponseBody
    @RequestMapping(value = "/checkRoleName/{roleName}", method = RequestMethod.POST)
    public R checkRoleName(@PathVariable("roleName") String roleName) {

        TbRoles role = adminService.getRoleByName(roleName);
        if (role != null) {
            return new R(500, "角色已存在");
        }

        return R.ok();
    }

    //[{"menuId":,'xxx':},{"menuId":,'xxx':}]
    //produces:该属性类似于response.setContentType()方法
    @ResponseBody
    @RequestMapping(value = "/getRolePermissionTree", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public String getRolePermissionTree(@RequestParam(value = "roleId", defaultValue = "-1") Long roleId) {

        //response.setContentType("application/json; charset=UTF-8");

        TbAdmin admin = new TbAdmin();
        admin.setRoleId(roleId);
        List<TbMenus> rolePermissionTree = adminService.getRolePermissionTree(admin);
        return JsonUtils.objectToJson(rolePermissionTree);
    }

    @RequestMapping(value = "/editRole", method = RequestMethod.GET)
    public String showEditRole(@RequestParam("roleId") Long roleId, Model model) {

        TbRoles role = adminService.getRoleById(roleId);
        model.addAttribute("role", role);

        return "page/admin/editRole";
    }

    /**
     * 需求:凡是有人修改了角色信息,就把该操作记录到数据库中.
     * 我们可以给该操作加个"标记"!
     */
    @SysLog(value = "修改角色")
    @ResponseBody
    @RequestMapping(value = "/updRole", method = RequestMethod.POST)
    public void editRole(TbRoles role, @RequestParam("m") String menuIds) {

        adminService.updateRole(role, menuIds);
    }

    @ResponseBody
    @RequestMapping(value = "/delRole/{roleId}", method = RequestMethod.GET)
    @RequiresPermissions("sys:role:delete")
    public R deleteOneRole(@PathVariable("roleId") Long roleId) {
        adminService.deleteOne(roleId);
        return R.ok();
    }

    @ResponseBody
    @RequestMapping(value = "/delRoles/{roleId}", method = RequestMethod.GET)
    @RequiresPermissions("sys:role:delete")
    public R deleteRoles(@PathVariable("roleId") String roleIds) {
        adminService.deleteMore(roleIds);
        return R.ok();
    }

}
