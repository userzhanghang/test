package com.syc.perms.pojo;

import lombok.Data;

@Data
public class UserSearch {

    private String nickname;

    private String sex;

    private String status;

    private String createTimeStart;

    private String createTimeEnd;

    private String operation;

}
