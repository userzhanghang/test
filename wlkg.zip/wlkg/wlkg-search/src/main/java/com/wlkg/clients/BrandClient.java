package com.wlkg.clients;

import com.wlkg.api.BrandApi;
import org.springframework.cloud.openfeign.FeignClient;

/**
 * @author 飞鸟
 * @create 2019-11-06 10:12
 */
@FeignClient(name = "item-service")
public interface BrandClient extends BrandApi {

}
