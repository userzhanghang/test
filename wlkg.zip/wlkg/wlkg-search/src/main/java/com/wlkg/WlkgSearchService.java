package com.wlkg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * @author 飞鸟
 * @create 2019-11-06 9:14
 */
@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients
public class WlkgSearchService {
    public static void main(String[] args) {
        //Eurake/Zuul/Feign/Ribbon/Hystrix
        SpringApplication.run(WlkgSearchService.class, args);
    }
}
