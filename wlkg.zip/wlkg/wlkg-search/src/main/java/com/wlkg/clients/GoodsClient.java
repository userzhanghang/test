package com.wlkg.clients;

import com.wlkg.api.GoodsApi;
import org.springframework.cloud.openfeign.FeignClient;

/**
 * @author 飞鸟
 * @create 2019-11-06 10:31
 */
@FeignClient(name ="item-service")
public interface GoodsClient extends GoodsApi {
}
