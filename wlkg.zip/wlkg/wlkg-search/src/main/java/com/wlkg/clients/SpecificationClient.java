package com.wlkg.clients;

import com.wlkg.api.SpecificationApi;
import org.springframework.cloud.openfeign.FeignClient;

/**
 * @author 飞鸟
 * @create 2019-11-06 10:48
 */
@FeignClient(name ="item-service")
public interface SpecificationClient extends SpecificationApi {
}
