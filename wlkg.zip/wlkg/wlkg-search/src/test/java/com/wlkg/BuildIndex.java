package com.wlkg;

import com.wlkg.clients.GoodsClient;
import com.wlkg.common.pojo.PageResult;
import com.wlkg.pojo.Goods;
import com.wlkg.pojo.Spu;
import com.wlkg.repository.GoodsRepository;
import com.wlkg.service.GoodsService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.ArrayList;
import java.util.List;

/**
 * @author 飞鸟
 * @create 2019-11-06 10:04
 */

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class BuildIndex {
    @Autowired
    private ElasticsearchTemplate template;

    @Autowired
    private GoodsRepository repository;

    @Autowired
    private GoodsClient goodsClient;
    @Autowired
    private GoodsService goodsService;


    @Test
    public void createIndex(){
        template.createIndex(Goods.class);
        template.putMapping(Goods.class);
    }

    @Test
    public void loadData(){
        long begin = System.currentTimeMillis();
        int page = 1;
        int rows = 100;
        int size = 0;
        do {
            // 查询分页数据
            PageResult<Spu> result = this.goodsClient.querySpuByPage(page-1, rows, true, null);
            List<Spu> spus = result.getItems();
            size = spus.size();
            // 创建Goods集合
            List<Goods> goodsList = new ArrayList<>();

            // 遍历spu
            for (Spu spu : spus) {
                try {
                    Goods goods = this.goodsService.buildGoods(spu);
                    System.out.println(goods+"----------------99999999999999999--------------------");
                    goodsList.add(goods);
                } catch (Exception e) {
                    break;
                }
            }
            System.out.println(goodsList+"---------------------------------------------");
            this.repository.saveAll(goodsList);
            page++;
        } while (size == 100);

        long end = System.currentTimeMillis();
        System.out.println("耗时："+(end-begin)/1000);
    }

}
