package com.wlkg.user.mapper;

import com.wlkg.pojo.User;
import tk.mybatis.mapper.common.Mapper;

public interface UserMapper extends Mapper<User> {
}
