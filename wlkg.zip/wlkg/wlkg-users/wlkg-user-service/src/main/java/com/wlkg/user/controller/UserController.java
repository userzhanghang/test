package com.wlkg.user.controller;

import com.wlkg.pojo.User;
import com.wlkg.user.service.UserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@Api("用户中心接口")
public class UserController {
    @Autowired
    private UserService userService;
    @GetMapping("/check/{data}/{type}")
    @ApiOperation(value = "验证用户数据接口，返回Boolean",notes = "验证用户数据")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "data",required = true,value = "用户数据"),
            @ApiImplicitParam(name = "type",required = true,value = "数据类型")}
    )
    public ResponseEntity<Boolean> checkUser(@PathVariable("data")String data,
                                             @PathVariable("type")Integer type){
        return ResponseEntity.ok(userService.checkUser(data,type));
    }
    @PostMapping("code")
    @ApiOperation(value = "发送验证码到接口", notes = "发送验证码")
    @ApiImplicitParam(name = "phone",required = true,value = "用户手机号")
    public ResponseEntity<Void> sendVerifyCode(String phone){
        Boolean boo = userService.sendVerifyCodeByPhone(phone);
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }

    @PostMapping("register")
    @ApiOperation(value = "用户注册接口",notes = "用户注册")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "user",required = true,value = "用户注册对象，包括用户名密码"),
            @ApiImplicitParam(name = "code",required = true,value = "验证码")
    })
    public ResponseEntity<Void> register(@Valid User user, @RequestParam("code")String code) {
        userService.register(user,code);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }
    @GetMapping("query")
    @ApiOperation(value = "用户查询接口",notes = "用户查询")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "username",required = true,value = "用户名"),
            @ApiImplicitParam(name = "passworrd",required = true,value = "用户密码")
    })
    public ResponseEntity<User> queryUser(@RequestParam("username")String username,
                                          @RequestParam("password")String password){
        User u = userService.queryUserBy(username,password);
        return ResponseEntity.ok(u);
    }
}
