package com.wlkg.user.service;

import com.wlkg.common.enums.ExceptionEnums;
import com.wlkg.common.exception.WlkgException;
import com.wlkg.common.utils.CodecUtils;
import com.wlkg.common.utils.NumberUtils;
import com.wlkg.pojo.User;
import com.wlkg.user.mapper.UserMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;


@Service
public class UserService {

    @Autowired
    private UserMapper userMapper;
    @Autowired
    private AmqpTemplate amqpTemplate;
    @Autowired
    private RedisTemplate redisTemplate;
    static final String KEY_PREFIX = "user:code:phone";
    static  final Logger logger = LoggerFactory.getLogger(UserService.class);
    public Boolean checkUser(String data, Integer type) {
        User record = new User();
        switch(type){
            case 1:
                record.setUsername(data);
                break;
            case 2:
                record.setPhone(data);
                break;
            default:
                return null;
        }
        return userMapper.selectCount(record) == 0;
    }

    public Boolean sendVerifyCodeByPhone(String phone) {
        String code = NumberUtils.generateCode(6);

        try{
            Map<String , String> maps = new HashMap<>();
            maps.put("phone",phone);
            maps.put("code",code);
            amqpTemplate.convertAndSend("wlkg.sms.exchange","sms.verify.code",maps);
            redisTemplate.opsForValue().set(KEY_PREFIX+phone,code,5, TimeUnit.MINUTES);
            return true;
        }catch (Exception e){
            logger.error("短信发送失败·phone{},code:{}",phone,code);
            return false;
        }

    }

    public void register(User user, String code) {
        String key = KEY_PREFIX + user.getPhone();

        String redisCode = (String) redisTemplate.opsForValue().get(key);

        if (!code.equals(redisCode)){
            throw new WlkgException(ExceptionEnums.INVALID_VERFIY_CODE);
        }
        user.setCreated(new Date());
        String salt =CodecUtils.generateSalt();
        user.setPassword(CodecUtils.md5Hex(user.getPassword(),salt));

       Boolean bool =  userMapper.insertSelective(user) == 1;
       if (bool){
           try{
               redisTemplate.delete(key);
           }catch (Exception e){
               logger.error("删除缓存验证码失败,code:{}",code,e);
           }
       }
    }

    public User queryUserBy(String username, String password) {
        User record = new User();
        record.setUsername(username);
        User u = userMapper.selectOne(record);
        if (u == null){
            throw new WlkgException(ExceptionEnums.INVALID_USERNAME_PASSWORD);
        }
        if(!u.getPassword().equals(CodecUtils.md5Hex(password,u.getSalt()))){
            throw new WlkgException(ExceptionEnums.INVALID_USERNAME_PASSWORD);
        }
        return u;
    }
}
