package com.wlkg.listener;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.Map;


@RunWith(SpringRunner.class)
public class WlkgSmsListenerTest {
    @Autowired
    private AmqpTemplate amqpTemplate;

    @Test
    public void listenSms() {
        Map<String,String> map = new HashMap<>();
        map.put("phone","17634445245");
        map.put("code","456789");
        amqpTemplate.convertAndSend("wlkg.sms.exchange","sms.verify.code",map);
        try{
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
