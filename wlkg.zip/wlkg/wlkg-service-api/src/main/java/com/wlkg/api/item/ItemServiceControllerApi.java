package com.wlkg.api.item;

import com.wlkg.common.pojo.PageResult;
import com.wlkg.pojo.Brand;
import io.swagger.annotations.Api;
import org.springframework.http.ResponseEntity;

import java.util.List;

/**
 * @author 飞鸟
 * @create 2019-10-28 19:25
 */
@Api(value = "品牌管理接口", description = "品牌管理接口，提供页面的增、删、改、查")
public interface ItemServiceControllerApi {
    public ResponseEntity<PageResult<Brand>> queryBrandByPage(Integer page, Integer rows, String sortBy, Boolean desc, String key) ;

    public ResponseEntity<Void> saveBrand(Brand brand, List<Long> cids);
}
