package com.wlkg.controller;

import com.wlkg.service.UploadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

/**
 * @author 飞鸟
 * @create 2019-10-28 9:21
 */
@RestController
public class UploadController {

    @Autowired
    private UploadService uploadService;

    //请求方式：POST
    //请求的url:/upload/image
    //请求参数:MultipartFile file
    //返回类型:图片的url
    @PostMapping("/upload/image")
    public ResponseEntity<String> uploadImage(@RequestParam("file") MultipartFile file) {
       String url =  uploadService.upload(file);
       return ResponseEntity.ok(url);
    }
}
