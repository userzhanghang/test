package com.wlkg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * @author 飞鸟
 * @create 2019-10-28 9:12
 */
@SpringBootApplication
@EnableDiscoveryClient
public class WlkgUpload {
    public static void main(String[] args) {
        SpringApplication.run(WlkgUpload.class, args);
    }
}
