package com.wlkg.page.client;

import com.wlkg.api.CategoryApi;
import org.springframework.cloud.openfeign.FeignClient;


@FeignClient(name ="item-service")
public interface CategoryClient extends CategoryApi {
}
