package com.wlkg.page.service;

import com.wlkg.page.client.BrandClient;
import com.wlkg.page.client.CategoryClient;
import com.wlkg.page.client.GoodsClient;
import com.wlkg.page.client.SpecificationClient;
import com.wlkg.page.util.ThreadUtils;
import com.wlkg.pojo.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
@Service
public class PageService {
    @Autowired
    private BrandClient brandClient;
    @Autowired
    private GoodsClient goodsClient;
    @Autowired
    private CategoryClient categoryClient;
    @Autowired
    private SpecificationClient specClient;
    @Autowired
    private TemplateEngine templateEngine;

    @Value("${wlkg.thymeleaf.destPath")
    private String destPath;

    public Map<String, Object> loadModel(Long id) {
        Map<String,Object> maps = new HashMap<>();
        Spu spu = goodsClient.querySpuById(id);
        SpuDetail detail = spu.getSpuDetail();
        List<Sku> skus = spu.getSkus();

        Brand brand = brandClient.queryBrandById(spu.getBrandId());

        List<Category> categories = categoryClient.queryCategoryByIds(
                Arrays.asList(spu.getCid1(),spu.getCid2(),spu.getCid3()));
        List<SpecGroup> specs = specClient.querySpecsByCid(spu.getCid3());
        maps.put("spu",spu);
        maps.put("subTitle",spu.getSubTitle());
        maps.put("title",spu.getTitle());
        maps.put("detail",detail);
        maps.put("skus",skus);
        maps.put("brand",brand);
        maps.put("categories",categories);
        maps.put("specs",specs);
        return maps;
    }

    public void syncCreateHtml(Long id){
        ThreadUtils.execute(() -> {
            try {
                createHtml(id);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public void createHtml(Long id) throws Exception {
        Context context = new Context();
        context.setVariables(loadModel(id));

        File temp = new File(id+".html");

        File dest = createPath(id);
        // 备份原页面文件
        File bak = new File(id + "_bak.html");
        try (PrintWriter writer = new PrintWriter(temp, "UTF-8")) {
            // 利用thymeleaf模板引擎生成 静态页面
            templateEngine.process("item", context, writer);
            if (dest.exists()) {
                // 如果目标文件已经存在，先备份
                dest.renameTo(bak);
            }
            // 将新页面覆盖旧页面
            FileCopyUtils.copy(temp, dest);
            // 成功后将备份页面删除
            bak.delete();
        }catch (IOException e){
            // 失败后，将备份页面恢复
            bak.renameTo(dest);
            // 重新抛出异常，声明页面生成失败
            throw new Exception(e);
        }finally {
            // 删除临时页面
            if (temp.exists()) {
                temp.delete();
            }
        }
    }

    private File createPath(Long id) {
        if (id == null){
            return null;
        }
        File dest = new File(destPath);
        if(!dest.exists()){
            dest.mkdirs();
        }
        return new File(dest, id + ".html");
    }

    public boolean exists(Long id){
        return this.createPath(id).exists();
    }
}
