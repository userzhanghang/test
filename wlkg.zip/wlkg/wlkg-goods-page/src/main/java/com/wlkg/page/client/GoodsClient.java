package com.wlkg.page.client;

import com.wlkg.api.GoodsApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name ="item-service")
public interface GoodsClient extends GoodsApi {
}
