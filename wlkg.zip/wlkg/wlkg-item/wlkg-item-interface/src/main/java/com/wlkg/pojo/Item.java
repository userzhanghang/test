package com.wlkg.pojo;

import lombok.Data;

/**
 * @author 飞鸟
 * @create 2019-10-24 10:40
 */
@Data
public class Item {
    private Integer id;
    private String name;
    private Long price;
}

