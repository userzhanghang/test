package com.wlkg.api;

import com.wlkg.pojo.Category;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

/**
 * @author 飞鸟
 * @create 2019-11-06 10:43
 */
public interface CategoryApi {
    @GetMapping("/category/list/ids")
    public List<Category> queryCategoryByIds(@RequestParam("ids") List<Long> ids);
}
