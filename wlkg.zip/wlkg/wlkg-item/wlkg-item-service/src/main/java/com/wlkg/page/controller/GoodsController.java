package com.wlkg.page.controller;

import com.wlkg.common.pojo.PageResult;
import com.wlkg.pojo.Sku;
import com.wlkg.pojo.Spu;
import com.wlkg.pojo.SpuDetail;
import com.wlkg.service.GoodsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author 飞鸟
 * @create 2019-10-30 15:10
 */
@RestController
public class GoodsController{
    @Autowired
    private GoodsService goodsService;

    //商品新增
    //1、请求方式：POST
    //2、请求的参数：Spu对象
    //3、url：/goods
    //4、返回类型：ResponseEntity<Void>
    @PostMapping("/goods")
    public ResponseEntity<Void> saveGoods(@RequestBody Spu spu) {
        goodsService.saveGoods(spu);
        return ResponseEntity.status(HttpStatus.CREATED).body(null);
    }


    //查询商品
    //1、请求方式：GET
    //2、请求的参数：page,rows,saleable,key
    //3、url：/spu/page
    //4、返回类型：ResponseEntity<PageResult<Spu>>
    @GetMapping("/spu/page")
    public ResponseEntity<PageResult<Spu>> querySpuByPage(
            @RequestParam(value = "page", defaultValue = "1") Integer page,
            @RequestParam(value = "rows", defaultValue = "5") Integer rows,
            @RequestParam(value = "saleable", required = false) Boolean saleable,
            @RequestParam(value = "key", required = false) String key) {
        PageResult<Spu> result = goodsService.querySpuByPage(page, rows, saleable, key);
        return ResponseEntity.ok(result);
    }

    //查询商品详情
    //1、请求方式：GET
    //2、请求的参数：spuId
    //3、url：/spu/detail/
    //4、返回类型：ResponseEntity<Spu_detail>
    @GetMapping("/spu/detail/{id}")
    public ResponseEntity<SpuDetail> querySpuDetailById(@PathVariable("id") Long id) {
        SpuDetail spuDetail = goodsService.querySpuDetailById(id);
        return ResponseEntity.ok(spuDetail);
    }

    //查询当前商品的所有sku信息
    //1、请求方式：GET
    //2、请求的参数：spuId
    //3、url：/sku/list
    //4、返回类型：ResponseEntity<List<Sku>>
    @GetMapping("/sku/list")
    public ResponseEntity<List<Sku>> querySkuBySpuId(@RequestParam("id") Long id) {
        List<Sku> list = goodsService.querySkuBySpuId(id);
        return ResponseEntity.ok(list);
    }

    //修改商品
    //1、请求方式：PUT
    //2、请求的参数：Spu对象
    //3、url：/goods
    //4、返回类型：ResponseEntity<Void>
    @PutMapping("/goods")
    public ResponseEntity<Void> updateGoods(@RequestBody Spu spu) {
        goodsService.updateGoods(spu);
        return ResponseEntity.status(HttpStatus.CREATED).body(null);
    }

    @GetMapping("spu/{id}")
    public ResponseEntity<Spu> querySpuById(@PathVariable("id") Long id){
        Spu spu = goodsService.querySpuById(id);
        return ResponseEntity.ok(spu);
    }

}
