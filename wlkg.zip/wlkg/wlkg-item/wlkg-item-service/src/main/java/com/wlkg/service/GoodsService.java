package com.wlkg.service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.wlkg.common.enums.ExceptionEnums;
import com.wlkg.common.exception.WlkgException;
import com.wlkg.common.pojo.PageResult;
import com.wlkg.mapper.SkuMapper;
import com.wlkg.mapper.SpuDetailMapper;
import com.wlkg.mapper.SpuMapper;
import com.wlkg.mapper.StockMapper;
import com.wlkg.pojo.*;
import org.apache.commons.lang.StringUtils;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import tk.mybatis.mapper.entity.Example;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author 飞鸟
 * @create 2019-10-30 15:21
 */
@Service
public class GoodsService {
    @Autowired
    private SpuMapper spuMapper;
    @Autowired
    private SpuDetailMapper spuDetailMapper;
    @Autowired
    private SkuMapper skuMapper;
    @Autowired
    private StockMapper stockMapper;

    @Autowired
    private CategoryService categoryService;
    @Autowired
    private BrandService brandService;

    @Autowired
    private AmqpTemplate amqpTemplate;

    /**
     * 实现商品添加
     *
     * @param spu
     */
    @Transactional
    public void saveGoods(Spu spu) {
        //1.添加spu
        spu.setSaleable(true);
        spu.setValid(true);
        spu.setCreateTime(new Date());
        spu.setLastUpdateTime(new Date());
        spuMapper.insert(spu);

        //2.添加spudetail
        SpuDetail spuDetail = spu.getSpuDetail();
        spuDetail.setSpuId(spu.getId());
        spuDetailMapper.insert(spuDetail);

        saveSkuAndStock(spu.getSkus(), spu.getId());

        sendMessage(spu.getId(),"insert");
    }

    /**
     * 实现商品查询
     *
     * @param page     当前页
     * @param rows     每一页的大小
     * @param saleable 上下架
     * @param key      关键词
     * @return
     */
    public PageResult<Spu> querySpuByPage(Integer page, Integer rows, Boolean saleable, String key) {

        PageHelper.startPage(page, Math.min(rows, 100));

        Example example = new Example(Spu.class);
        Example.Criteria criteria = example.createCriteria();
        //1.设置上下架条件
        if (saleable != null) {
            criteria.andEqualTo("saleable", saleable);
        }

        //2.设置关键词搜索
        if (StringUtils.isNotBlank(key)) {
            criteria.andLike("title", "%" + key + "%");
        }

        //3.设置默认排序
        example.setOrderByClause("last_update_time desc");
        List<Spu> list = spuMapper.selectByExample(example);

        if (CollectionUtils.isEmpty(list)) {
            throw new WlkgException(ExceptionEnums.GOODS_SPU_IS_EMPTY);
        }

        for (Spu spu : list) {
            List<Category> categories = categoryService.queryCategorysByCids(Arrays.asList(spu.getCid1(), spu.getCid2(), spu.getCid3()));
            //将每个分类对象的分类名称取出来拼接成字符串
            String res = "";
            /*

            for(Category c : categories){
                res += c.getName()+"/";
            }
            res = res.substring(0, res.length()-1);
            */
            List<String> resList = categories.stream().map(c -> c.getName()).collect(Collectors.toList());
            res = StringUtils.join(resList, "/");
            //1.封装分类信息
            spu.setCname(res);//设置分类名称

            //2.封装品牌信息
            Brand brand = brandService.queryBrandById(spu.getBrandId());
            spu.setBname(brand.getName());//设置品牌名称
        }
        //3.返回分页对象
        PageInfo<Spu> pageInfo = new PageInfo<>(list);

        PageResult<Spu> spuPageResult = new PageResult<>();
        spuPageResult.setTotal(pageInfo.getTotal());
        spuPageResult.setTotalPage(Long.valueOf(pageInfo.getPages()));
        spuPageResult.setItems(list);

        return spuPageResult;
    }

    /**
     * 根据商品Id查询商品详情
     *
     * @param id
     * @return
     */
    public SpuDetail querySpuDetailById(Long id) {
        SpuDetail detail = spuDetailMapper.selectByPrimaryKey(id);
        if (detail == null) {
            throw new WlkgException(ExceptionEnums.GOODS_DETAIL_IS_EMPTY);
        }
        return detail;
    }

    /**
     * 根据商品id查询所有的sku信息
     *
     * @param id
     * @return
     */
    public List<Sku> querySkuBySpuId(Long id) {
        Sku sku = new Sku();
        sku.setSpuId(id);
        List<Sku> skus = skuMapper.select(sku);

        if (CollectionUtils.isEmpty(skus)) {
            throw new WlkgException(ExceptionEnums.GOODS_SKU_IS_EMPTY);
        }

        //查询每个sku所关联的库存
        for (Sku s : skus) {
            Stock stock = stockMapper.selectByPrimaryKey(s.getId());
            s.setStock(stock.getStock());
        }

        return skus;
    }

    /**
     * 修改商品
     *
     * @param spu
     */
    @Transactional
    public void updateGoods(Spu spu) {

        //1.修改spu
        //修改spu
        spu.setValid(null);
        spu.setSaleable(null);
        spu.setLastUpdateTime(new Date());
        spu.setCreateTime(null);
        int rows = spuMapper.updateByPrimaryKeySelective(spu);

        if (rows <= 0) {
            throw new WlkgException(ExceptionEnums.UPDATE_SPU_IS_ERROR);
        }
        //2.修改spudetail
        SpuDetail spuDetail = spu.getSpuDetail();
        rows = spuDetailMapper.updateByPrimaryKey(spuDetail);
        if (rows <= 0) {
            throw new WlkgException(ExceptionEnums.UPDATE_SPU_DETAIL_IS_ERROR);
        }

        //3.删除sku
        Sku sku = new Sku();
        sku.setSpuId(spu.getId());
        //查询sku
        List<Sku> skuList = skuMapper.select(sku);

        //5.删除stock
        //Supplier(T get()),Consumer(accept(T)),Predicate(boolean test(T)),Function(R apply(T))
        List<Long> ids = skuList.stream().map(s->s.getId()).collect(Collectors.toList());
        stockMapper.deleteByIdList(ids);


        rows = skuMapper.delete(sku);//delete from sku where spu_id=??
        if (rows <= 0) {
            throw new WlkgException(ExceptionEnums.UPDATE_SKU_IS_ERROR);
        }

        //4.添加sku
        //6.添加stock
        saveSkuAndStock(spu.getSkus(), spu.getId());

        sendMessage(spu.getId(),"update");
    }

    private void saveSkuAndStock(List<Sku> skus, Long spuId) {
        List<Stock> stocks = new ArrayList<>();
        for (Sku sku : skus) {
            if (!sku.getEnable()) {
                continue;
            }
            // 保存sku
            sku.setSpuId(spuId);
            // 默认不参与任何促销
            sku.setCreateTime(new Date());

            sku.setLastUpdateTime(sku.getCreateTime());
            this.skuMapper.insert(sku);

            // 保存库存信息
            Stock stock = new Stock();
            stock.setSkuId(sku.getId());
            stock.setStock(sku.getStock().intValue());
            stocks.add(stock);
        }

        //批量新增库存
        stockMapper.insertList(stocks);
    }

    public Spu querySpuById(Long id) {
        Spu spu = spuMapper.selectByPrimaryKey(id);
        if (spu == null){
             throw new WlkgException(ExceptionEnums.GOODS_SPU_IS_EMPTY);
        }
        spu.setSkus(querySkuBySpuId(id));
        //查询detail
        spu.setSpuDetail(querySpuDetailById(id));
        return spu;
    }

    private void sendMessage(Long id , String type){
        try{
              amqpTemplate.convertAndSend("item."+type,id);
        }catch (Exception e){
              e.printStackTrace();
        }
    }
}
