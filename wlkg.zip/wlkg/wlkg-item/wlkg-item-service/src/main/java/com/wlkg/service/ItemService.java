package com.wlkg.service;

import com.wlkg.common.enums.ExceptionEnums;
import com.wlkg.common.exception.WlkgException;
import com.wlkg.pojo.Item;
import org.springframework.stereotype.Service;

import java.util.Random;

/**
 * @author 飞鸟
 * @create 2019-10-24 10:43
 */
@Service
public class ItemService {

    public Item saveItem(Item item){
        //如果价格为空，则抛出异常，返回400状态码，请求参数有误
        if (item.getPrice() == null) {
            throw new WlkgException(ExceptionEnums.PRICE_CANNOT_BE_NULL);
        }

        int id = new Random().nextInt(100);
        item.setId(id);

        return item;
    }
}
