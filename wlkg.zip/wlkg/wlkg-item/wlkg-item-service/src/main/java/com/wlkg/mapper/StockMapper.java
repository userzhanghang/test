package com.wlkg.mapper;

import com.wlkg.pojo.Stock;
import tk.mybatis.mapper.additional.idlist.DeleteByIdListMapper;
import tk.mybatis.mapper.additional.insert.InsertListMapper;//插入前需要设置主键值
import tk.mybatis.mapper.common.Mapper;

/**
 * @author 飞鸟
 * @create 2019-10-30 15:34
 */
public interface StockMapper extends Mapper<Stock>, InsertListMapper<Stock>, DeleteByIdListMapper<Stock, Long> {
}
