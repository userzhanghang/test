package com.wlkg.mapper;

import com.wlkg.pojo.Sku;
import tk.mybatis.mapper.common.Mapper;
import tk.mybatis.mapper.common.special.InsertListMapper;

/**
 * @author 飞鸟
 * @create 2019-10-30 15:27
 */
public interface SkuMapper extends Mapper<Sku>, InsertListMapper<Sku> {

}
