package com.wlkg.mapper;

import com.wlkg.pojo.Spu;
import tk.mybatis.mapper.common.Mapper;

/**
 * @author 飞鸟
 * @create 2019-10-30 15:23
 */
public interface SpuMapper extends Mapper<Spu> {
}
