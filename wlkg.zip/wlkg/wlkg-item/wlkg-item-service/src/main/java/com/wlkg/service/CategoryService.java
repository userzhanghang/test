package com.wlkg.service;

import com.wlkg.common.enums.ExceptionEnums;
import com.wlkg.common.exception.WlkgException;
import com.wlkg.mapper.CategoryMapper;
import com.wlkg.pojo.Category;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;

/**
 * @author 飞鸟
 * @create 2019-10-24 15:08
 */
@Service
public class CategoryService {
    @Autowired
    private CategoryMapper categoryMapper;

    /**
     * 根据pid查询节点
     *
     * @param pid
     * @return
     */
    public List<Category> list(Long pid) {
        Category c = new Category();
        c.setParentId(pid);

        List<Category> list = categoryMapper.select(c);
        if (CollectionUtils.isEmpty(list)) {
            //空数据
            throw new WlkgException(ExceptionEnums.CATEGORY_IS_EMPTY);
        }
        return list;
    }

    public List<Category> queryByBrandId(Long bid) {
        return this.categoryMapper.queryByBrandId(bid);
    }

    /**
     * 根据多个主键查询
     *
     * @param cids
     * @return
     */
    public List<Category> queryCategorysByCids(List<Long> cids) {
        return this.categoryMapper.selectByIdList(cids);
    }

    /**
     * 根据分类id集合查询每个分类对象
     *
     * @param ids
     * @return
     */
    public List<Category> queryByIds(List<Long> ids) {
        List<Category> list = categoryMapper.selectByIdList(ids);
        if (CollectionUtils.isEmpty(list)) {
            throw new WlkgException(ExceptionEnums.CATEGORY_IS_EMPTY);
        }
        return list;
    }
}
