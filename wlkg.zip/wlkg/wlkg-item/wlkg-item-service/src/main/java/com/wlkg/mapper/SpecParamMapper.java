package com.wlkg.mapper;

import com.wlkg.pojo.SpecParam;
import tk.mybatis.mapper.common.Mapper;

/**
 * @author 飞鸟
 * @create 2019-10-29 10:47
 */
public interface SpecParamMapper extends Mapper<SpecParam> {
}
