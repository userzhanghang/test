package com.wlkg.mapper;

import com.wlkg.pojo.SpecGroup;
import tk.mybatis.mapper.common.Mapper;

/**
 * @author 飞鸟
 * @create 2019-10-29 10:22
 */
public interface SpecGroupMapper extends Mapper<SpecGroup> {
}
