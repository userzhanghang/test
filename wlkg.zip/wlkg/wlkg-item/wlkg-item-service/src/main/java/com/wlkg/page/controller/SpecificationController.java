package com.wlkg.page.controller;

import com.wlkg.pojo.SpecGroup;
import com.wlkg.pojo.SpecParam;
import com.wlkg.service.SpecificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author 飞鸟
 * @create 2019-10-29 10:13
 */

@RestController
public class SpecificationController {
    @Autowired
    private SpecificationService specificationService;

    //1.根据分类查询规格组
    //提交方式：GET
    //url:/spec/groups/
    //参数:Long cid
    //返回类型:List<SpecGroup>

    @GetMapping("/spec/groups/{cid}")
    public ResponseEntity<List<SpecGroup>> querySpecGroups(@PathVariable("cid") Long cid) {
        List<SpecGroup> list = specificationService.querySpecsByCid(cid);
        return ResponseEntity.ok(list);
    }


    //2.根据规格组编号查询规格属性
    //提交方式：GET
    //url:/item/spec/params?gid=
    //参数:Long gid
    //返回类型:List<SpecParam>

    @GetMapping("/spec/params")
    public ResponseEntity<List<SpecParam>> querySpecParam(
            @RequestParam(value = "gid", required = false) Long gid,
            @RequestParam(value = "cid", required = false) Long cid,
            @RequestParam(value = "searching", required = false) Boolean searching,
            @RequestParam(value = "generic", required = false) Boolean generic
    ) {
        List<SpecParam> list = specificationService.querySpecParamByGid(gid, cid, searching, generic);
        return ResponseEntity.ok(list);
    }
    @GetMapping("/spec/group")
    public ResponseEntity<List<SpecGroup>> querySpecsByCid(@RequestParam("cid") Long cid){
        List<SpecGroup> list = this.specificationService.querySpecsByCid(cid);
        return ResponseEntity.ok(list);
    }

}