package com.wlkg.service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.wlkg.common.enums.ExceptionEnums;
import com.wlkg.common.exception.WlkgException;
import com.wlkg.common.pojo.PageResult;
import com.wlkg.mapper.BrandMapper;
import com.wlkg.pojo.Brand;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import tk.mybatis.mapper.entity.Example;

import java.util.List;

/**
 * @author 飞鸟
 * @create 2019-10-26 9:44
 */
@Service
public class BrandService {
    @Autowired
    private BrandMapper brandMapper;

    /**
     * 实现品牌的分页查询
     * @param page
     * @param rows
     * @param sortBy
     * @param desc
     * @param key
     * @return
     */
    public PageResult<Brand> queryBrandByPageAndSort(Integer page, Integer rows, String sortBy, Boolean desc, String key) {
        //1.实现分页查询
        PageHelper.startPage(page,rows);

        //List<Brand> list = brandMapper.selectAll();
        Example example = new Example(Brand.class);
        //2.设置过滤字段
        if(StringUtils.isNotBlank(key)){
            example.createCriteria().andLike("name","%"+key+"%").orEqualTo("letter",key);
        }

        //3.设置排序
        if(StringUtils.isNotBlank(sortBy)){
            example.setOrderByClause(sortBy+ (desc ?" desc":" asc"));
        }

        List<Brand> list =brandMapper.selectByExample(example);//Page<Brand> extends ArrayList
        if(CollectionUtils.isEmpty(list)){
            throw new WlkgException(ExceptionEnums.BRAND_IS_EMPTY);
        }

        PageInfo<Brand> pageInfo = new PageInfo<>(list);
        //4. 封装分页对象
        PageResult<Brand> result = new PageResult<>();
        result.setItems(list);
        result.setTotalPage(Long.valueOf(pageInfo.getPages()));
        result.setTotal(pageInfo.getTotal());
        return result;
    }

    /**
     * 添加新品牌
     * @param brand
     * @param cids
     */
    @Transactional
    public void saveBrand(Brand brand, List<Long> cids) {
        //1.添加品牌
        brandMapper.insert(brand);


        //2.添加该品牌关联的分类
        for(Long cid :cids){
            brandMapper.insertCategoryBrand(cid, brand.getId());
        }

    }

    /**
     * 根据分类Id查询品牌
     * @param cid
     * @return
     */
    public List<Brand> queryBrandByCid(Long cid) {
        List<Brand> list = brandMapper.selectBrandByCid(cid);
        if(CollectionUtils.isEmpty(list)){
            throw new WlkgException(ExceptionEnums.BRAND_IS_EMPTY);
        }
        return list;
    }

    /**
     * 根据品牌Id查询品牌对象
     * @param brandId
     * @return
     */
    public Brand queryBrandById(Long brandId){
        return brandMapper.selectByPrimaryKey(brandId);
    }

}
