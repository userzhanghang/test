package com.wlkg.auth;

import com.wlkg.auth.entity.UserInfo;
import com.wlkg.auth.utils.JwtUtils;
import com.wlkg.auth.utils.ResUtils;
import org.junit.Before;
import org.junit.Test;

import java.security.PrivateKey;
import java.security.PublicKey;

public class JwtTest {
    private static final String pubKeyPath = "D:\\tmp\\res\\res.pub";
    private static final String priKeyPath = "D:\\tmp\\res\\res.pri";

    private PublicKey publicKey;

    private PrivateKey privateKey;

    @Test
    public void testRes() throws Exception {
        ResUtils.generateKey(pubKeyPath,priKeyPath,"1234567");
    }

    @Before
    public void testGetRes() throws Exception {
        publicKey = ResUtils.getPublicKey(pubKeyPath);
        privateKey = ResUtils.getPrivateKey(priKeyPath);
    }
    @Test
    public void testGenerateToke() throws Exception {
        String token = JwtUtils.generateToken(new UserInfo(20L,"jack"),privateKey,5);
        System.out.println("token = "+ token);
    }

    @Test
    public void testParseToken() throws Exception {
        String token = "eyJhbGciOiJSUzI1NiJ9.eyJpZCI6MjAsInVzZXJuYW1lIjoiamFjayIsImV4cCI6MTU3MzczMTU4Nn0.S2T7-yQZvZ2jzELPz2A1CXIMZPRRxXaM-1CVnK_DzXSsqZPuf3tlDCZo9k7qKw79tYSfHuNq7AH4GG8U2eX8TYFL5H3fieQbb0M4XjzpdgXeJ8Ku7_lxOkRkKaRRxefIk0I7dvad5tUGWs9yj7EtojfBgvwGd7S9OKDPMpEzDNE";
        UserInfo info = JwtUtils.getInfoFromToken(token,publicKey);
        System.out.println("id:"+info.getId());
        System.out.println("userName:"+ info.getUsername());
    }
}
